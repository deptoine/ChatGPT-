Attribute VB_Name = "NettoyageMDOSUIVI"
Option Explicit

' Excel Windows. No reference or VBA project access permission required.
Public Sub InstallerBouton()
    Dim ws As Worksheet, bouton As Shape
    On Error GoTo Echec
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets("Nettoyage CSV")
    On Error GoTo Echec
    If ws Is Nothing Then
        Set ws = ThisWorkbook.Worksheets.Add
        ws.Name = "Nettoyage CSV"
    End If
    ws.Range("A1").Value = "NETTOYAGE MDOSUIVI"
    ws.Range("A1").Font.Size = 22
    ws.Range("A1").Font.Bold = True
    ws.Range("A3").Value = "S�lectionnez le CSV du jour. Une copie nettoy�e sera cr��e � c�t�."
    ws.Range("A4").Value = "R�gle : m�me affaire (D) + m�me sous-type (AA), avec un Conforme et num�ris�."
    ws.Range("A5").Value = "Seuls En attente v�rification et En attente num�risation sont supprim�s."
    ws.Columns("A").ColumnWidth = 105
    On Error Resume Next
    ws.Shapes("btnNettoyer").Delete
    On Error GoTo Echec
    Set bouton = ws.Shapes.AddShape(5, 15, 120, 370, 50)
    bouton.Name = "btnNettoyer"
    bouton.TextFrame.Characters.Text = "Choisir et nettoyer le CSV du jour"
    bouton.Fill.ForeColor.RGB = RGB(24, 92, 120)
    bouton.TextFrame.Characters.Font.Color = RGB(255, 255, 255)
    bouton.OnAction = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!ImporterEtNettoyer"
    ws.Activate
    MsgBox "Bouton install�. Enregistrez ce classeur au format .xlsm.", vbInformation
    Exit Sub
Echec:
    MsgBox "Installation impossible : " & Err.Description, vbExclamation
End Sub

Public Sub ImporterEtNettoyer()
    Dim choix As Variant, chemin As String, sortie As String, texte As String
    Dim encodage As String, avecBOM As Boolean, enregistrements As Collection
    Dim conformes As Object, champs As Variant, cle As String, statut As String
    Dim garder() As String, i As Long, n As Long, supprimees As Long, total As Long
    Dim prefixe As String, suffixe As Long, fso As Object, message As String
    Dim ancienStatus As Variant
    ancienStatus = Application.StatusBar
    On Error GoTo Echec
    choix = Application.GetOpenFilename("Fichiers CSV (*.csv),*.csv", , "Choisir le fichier MDOSUIVI du jour")
    If VarType(choix) = vbBoolean Then Exit Sub
    chemin = CStr(choix)
    Application.StatusBar = "Lecture et v�rification du CSV..."
    texte = LireTexte(chemin, encodage, avecBOM)
    Set enregistrements = DecouperCSV(texte)
    If enregistrements.Count = 0 Then Err.Raise vbObjectError + 1, , "Fichier vide."
    champs = LireChamps(CStr(enregistrements(1)))
    If UBound(champs) < 27 Then Err.Raise vbObjectError + 2, , "CSV attendu : s�parateur point-virgule et au moins 28 colonnes."
    If Normaliser(champs(3)) <> "ie_affaire" Or Normaliser(champs(26)) <> "sous type de document" Or Normaliser(champs(27)) <> "statut" Then
        Err.Raise vbObjectError + 3, , "Les colonnes D, AA et AB ne correspondent pas au fichier attendu."
    End If
    Set conformes = CreateObject("Scripting.Dictionary")
    conformes.CompareMode = vbBinaryCompare
    For i = 2 To enregistrements.Count
        If Len(Trim$(SansFinLigne(CStr(enregistrements(i))))) > 0 Then
            champs = LireChamps(CStr(enregistrements(i)))
            If UBound(champs) < 27 Then Err.Raise vbObjectError + 4, , "Enregistrement incomplet : " & i
            cle = CleDocument(champs)
            If cle <> "" And Normaliser(champs(27)) = "conforme et num�ris�" Then conformes(cle) = True
        End If
    Next i
    ReDim garder(0 To enregistrements.Count - 1)
    garder(0) = CStr(enregistrements(1))
    n = 1
    For i = 2 To enregistrements.Count
        cle = "": statut = ""
        If Len(Trim$(SansFinLigne(CStr(enregistrements(i))))) > 0 Then
            total = total + 1
            champs = LireChamps(CStr(enregistrements(i)))
            cle = CleDocument(champs)
            statut = Normaliser(champs(27))
        End If
        If cle <> "" And conformes.Exists(cle) And (statut = "en attente v�rification" Or statut = "en attente num�risation") Then
            supprimees = supprimees + 1
        Else
            garder(n) = CStr(enregistrements(i))
            n = n + 1
        End If
    Next i
    ReDim Preserve garder(0 To n - 1)
    Set fso = CreateObject("Scripting.FileSystemObject")
    prefixe = Left$(chemin, InStrRev(chemin, ".") - 1) & "_nettoye"
    sortie = prefixe & ".csv"
    Do While fso.FileExists(sortie)
        suffixe = suffixe + 1
        sortie = prefixe & "_" & suffixe & ".csv"
    Loop
    Application.StatusBar = "Enregistrement de la copie nettoy�e..."
    EcrireTexte sortie, Join(garder, ""), encodage, avecBOM
    Application.StatusBar = ancienStatus
    MsgBox Format$(total, "#,##0") & " lignes lues" & vbCrLf & Format$(supprimees, "#,##0") & " lignes supprim�es" & vbCrLf & Format$(total - supprimees, "#,##0") & " lignes conserv�es" & vbCrLf & vbCrLf & "Fichier cr�� :" & vbCrLf & sortie, vbInformation, "Nettoyage termin�"
    Exit Sub
Echec:
    message = Err.Description
    Application.StatusBar = ancienStatus
    MsgBox "Nettoyage interrompu : " & message & vbCrLf & "Le fichier source est inchang�.", vbExclamation
End Sub

Private Function CleDocument(ByVal c As Variant) As String
    Dim a As String, s As String
    a = Trim$(CStr(c(3))): s = Trim$(CStr(c(26)))
    If a = "" Or s = "" Then Exit Function
    CleDocument = CStr(Len(a)) & ":" & a & s
End Function

Private Function Normaliser(ByVal s As String) As String
    s = Replace(s, ChrW(160), " ")
    s = Replace(s, vbTab, " ")
    s = Replace(s, vbCr, " "): s = Replace(s, vbLf, " ")
    Do While InStr(s, "  ") > 0
        s = Replace(s, "  ", " ")
    Loop
    Normaliser = LCase$(Trim$(s))
End Function

Private Function SansFinLigne(ByVal s As String) As String
    Do While Len(s) > 0
        If Right$(s, 1) <> vbCr And Right$(s, 1) <> vbLf Then Exit Do
        s = Left$(s, Len(s) - 1)
    Loop
    SansFinLigne = s
End Function

' Keep every retained record verbatim, including delimiters and line endings.
Private Function DecouperCSV(ByVal s As String) As Collection
    Dim r As New Collection, i As Long, debut As Long, q As Boolean, c As String
    debut = 1: i = 1
    Do While i <= Len(s)
        c = Mid$(s, i, 1)
        If c = Chr$(34) Then
            If q And Mid$(s, i + 1, 1) = Chr$(34) Then
                i = i + 1
            Else
                q = Not q
            End If
        ElseIf Not q And (c = vbCr Or c = vbLf) Then
            If c = vbCr And Mid$(s, i + 1, 1) = vbLf Then i = i + 1
            r.Add Mid$(s, debut, i - debut + 1)
            debut = i + 1
        End If
        i = i + 1
    Loop
    If q Then Err.Raise vbObjectError + 5, , "Guillemets non ferm�s dans le CSV."
    If debut <= Len(s) Then r.Add Mid$(s, debut)
    Set DecouperCSV = r
End Function

Private Function LireChamps(ByVal s As String) As Variant
    Dim champs() As String, n As Long, i As Long, q As Boolean, c As String
    ReDim champs(0 To 0)
    s = SansFinLigne(s): i = 1
    Do While i <= Len(s)
        c = Mid$(s, i, 1)
        If c = Chr$(34) Then
            If q And Mid$(s, i + 1, 1) = Chr$(34) Then
                champs(n) = champs(n) & c: i = i + 1
            Else
                q = Not q
            End If
        ElseIf c = ";" And Not q Then
            n = n + 1: ReDim Preserve champs(0 To n)
        Else
            champs(n) = champs(n) & c
        End If
        i = i + 1
    Loop
    LireChamps = champs
End Function

Private Function LireTexte(ByVal chemin As String, ByRef encodage As String, ByRef avecBOM As Boolean) As String
    Dim flux As Object, b As Variant
    Set flux = CreateObject("ADODB.Stream")
    flux.Type = 1: flux.Open: flux.LoadFromFile chemin
    encodage = "windows-1252": avecBOM = False
    If flux.Size >= 3 Then
        b = flux.Read(3)
        If b(0) = 239 And b(1) = 187 And b(2) = 191 Then
            encodage = "utf-8": avecBOM = True
        End If
        If b(0) = 255 And b(1) = 254 Or b(0) = 254 And b(1) = 255 Then
            flux.Close
            Err.Raise vbObjectError + 6, , "Encodage UTF-16 non pris en charge. Utilisez le CSV Windows-1252 habituel ou UTF-8 avec BOM."
        End If
    End If
    flux.Position = 0: flux.Type = 2: flux.Charset = encodage
    LireTexte = flux.ReadText
    flux.Close
    If Len(LireTexte) > 0 Then
        If AscW(Left$(LireTexte, 1)) = -257 Then LireTexte = Mid$(LireTexte, 2)
    End If
End Function

Private Sub EcrireTexte(ByVal chemin As String, ByVal s As String, ByVal encodage As String, ByVal avecBOM As Boolean)
    Dim flux As Object
    Set flux = CreateObject("ADODB.Stream")
    flux.Type = 2: flux.Charset = encodage: flux.Open
    flux.WriteText s
    flux.SaveToFile chemin, 1 ' Create only: never overwrite a file.
    flux.Close
End Sub
